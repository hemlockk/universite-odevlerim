<?php
  $un = $_POST['name'];
  $pw = $_POST['pass'];
  $Username = "g191210012@hotmail.com";
  $password = "123";
    if($un == $Username && $pw == $password){
      echo "hoşgeldin $un";
    }
    else{
        header("Location:login.html");
    }
 ?>
